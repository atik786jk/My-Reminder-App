# My Reminder — Atik Edition

A polished dark-mode Android reminder app with:
- Premium blue/purple theme
- Animated splash and home screen
- Custom reminder scheduling + notifications
- Online men's football fixture panel
- App icon and developer credit: Atik

## GitHub Actions
The workflow at `.github/workflows/build-apk.yml` builds a debug APK and uploads it as an artifact.

## Build
Push to `main`, then open **Actions → Build Android APK**. Download the `MyReminder-debug-apk` artifact.
