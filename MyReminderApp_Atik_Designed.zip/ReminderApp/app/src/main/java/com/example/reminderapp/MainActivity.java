package com.example.reminderapp;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.animation.AnimationUtils;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    Calendar chosen = Calendar.getInstance();
    TextView footballText, reminderStatus;
    int white=Color.rgb(248,250,252), muted=Color.rgb(154,168,199), blue=Color.rgb(77,141,255), purple=Color.rgb(168,85,247);

    @Override public void onCreate(Bundle b){ super.onCreate(b); showSplash(); if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10); }

    void showSplash(){
        FrameLayout f=new FrameLayout(this); f.setBackgroundResource(com.example.reminderapp.R.drawable.bg_gradient);
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER); box.setPadding(32,32,32,32);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.ic_launcher); box.addView(logo,new LinearLayout.LayoutParams(130,130));
        TextView title=txt("My Reminder",34,white,true); title.setGravity(Gravity.CENTER); box.addView(title,lp(-1,-2));
        TextView sub=txt("Never Miss What Matters",16,muted,false); sub.setGravity(Gravity.CENTER); box.addView(sub,lp(-1,-2));
        Space sp=new Space(this); box.addView(sp,lp(1,35));
        TextView dev=txt("Developed by Atik",14,white,true); dev.setGravity(Gravity.CENTER); box.addView(dev,lp(-1,-2));
        f.addView(box,new FrameLayout.LayoutParams(-1,-1)); setContentView(f);
        box.startAnimation(AnimationUtils.loadAnimation(this,R.anim.fade_in));
        new Handler().postDelayed(this::showHome,1100);
    }

    void showHome(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(7,11,24));
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(20,18,20,32); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);

        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(2,2,2,14);
        LinearLayout names=new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL);
        names.addView(txt("Good day, Atik 👋",25,white,true),lp(-1,-2));
        names.addView(txt("Stay organized. Stay ahead.",14,muted,false),lp(-1,-2));
        top.addView(names,new LinearLayout.LayoutParams(0,-2,1));
        TextView gear=txt("⚙",27,white,true); gear.setGravity(Gravity.CENTER); gear.setBackground(round(Color.rgb(17,26,46),20)); top.addView(gear,new LinearLayout.LayoutParams(52,52)); gear.setOnClickListener(v->showSettings());
        content.addView(top);

        LinearLayout hero=card(); hero.setBackgroundResource(R.drawable.bg_gradient);
        LinearLayout heroText=new LinearLayout(this); heroText.setOrientation(LinearLayout.VERTICAL);
        heroText.addView(txt("YOUR DAY, YOUR WAY",12,Color.rgb(191,219,254),true),lp(-1,-2));
        TextView h=txt("Never miss the\nthings that matter.",26,white,true); h.setPadding(0,4,0,8); heroText.addView(h,lp(-1,-2));
        heroText.addView(txt("Set a reminder in seconds and get a notification exactly when you need it.",14,Color.rgb(207,214,233),false),lp(-1,-2));
        hero.addView(heroText,new LinearLayout.LayoutParams(0,-2,1));
        ImageView mini=new ImageView(this); mini.setImageResource(R.drawable.ic_launcher); hero.addView(mini,new LinearLayout.LayoutParams(70,70));
        content.addView(hero,lp(-1,-2));

        Space gap=new Space(this); content.addView(gap,lp(1,14));
        TextView add=txt("＋  Add Reminder",16,white,true); add.setGravity(Gravity.CENTER); add.setBackgroundResource(R.drawable.primary_btn); add.setElevation(4); add.setOnClickListener(v->addReminderDialog()); content.addView(add,lp(-1,58));

        TextView sec=txt("Quick access",18,white,true); sec.setPadding(2,22,0,10); content.addView(sec,lp(-1,-2));
        LinearLayout quick=new LinearLayout(this); quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(quickCard("⏰","Today","Reminders"),weightLp(1)); quick.addView(quickCard("⚽","Football","Men's only"),weightLp(1)); quick.addView(quickCard("🔔","Alerts","Enabled"),weightLp(1)); content.addView(quick);

        TextView ftitle=txt("⚽  Football",20,white,true); ftitle.setPadding(2,22,0,10); content.addView(ftitle,lp(-1,-2));
        LinearLayout fc=card(); fc.setOrientation(LinearLayout.VERTICAL);
        LinearLayout ftop=new LinearLayout(this); ftop.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ball=new ImageView(this); ball.setImageResource(R.drawable.football_ball); ftop.addView(ball,new LinearLayout.LayoutParams(38,38));
        LinearLayout ft=new LinearLayout(this); ft.setOrientation(LinearLayout.VERTICAL); ft.setPadding(10,0,0,0); ft.addView(txt("Men's Football",16,white,true),lp(-1,-2)); ft.addView(txt("Online fixtures • tap to refresh",12,muted,false),lp(-1,-2)); ftop.addView(ft,new LinearLayout.LayoutParams(0,-2,1));
        TextView refresh=txt("↻",27,white,true); refresh.setGravity(Gravity.CENTER); refresh.setBackground(round(Color.rgb(24,36,61),18)); ftop.addView(refresh,new LinearLayout.LayoutParams(48,48)); fc.addView(ftop); footballText=txt("Loading today's fixtures…",13,muted,false); footballText.setPadding(0,12,0,0); fc.addView(footballText); refresh.setOnClickListener(v->loadFootball()); content.addView(fc);

        TextView rtitle=txt("⏱  Quick Reminder",20,white,true); rtitle.setPadding(2,22,0,10); content.addView(rtitle,lp(-1,-2));
        LinearLayout rc=card(); rc.setOrientation(LinearLayout.VERTICAL); reminderStatus=txt("No reminder set yet",15,muted,false); rc.addView(reminderStatus,lp(-1,-2)); TextView pick=txt("Choose time",14,white,true); pick.setGravity(Gravity.CENTER); pick.setBackgroundResource(R.drawable.secondary_btn); pick.setOnClickListener(v->pickTime()); rc.addView(pick,lp(-1,50)); content.addView(rc);

        TextView foot=txt("My Reminder  •  Developed by Atik\nSimple  •  Useful  •  Always with you",13,muted,false); foot.setGravity(Gravity.CENTER); foot.setPadding(0,28,0,0); content.addView(foot,lp(-1,-2));
        content.startAnimation(AnimationUtils.loadAnimation(this,R.anim.slide_up));
        loadFootball();
    }

    LinearLayout quickCard(String icon,String title,String sub){ LinearLayout c=card(); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER); TextView i=txt(icon,25,white,true); i.setGravity(Gravity.CENTER); c.addView(i,lp(-1,34)); TextView t=txt(title,13,white,true); t.setGravity(Gravity.CENTER); c.addView(t,lp(-1,-2)); TextView s=txt(sub,10,muted,false); s.setGravity(Gravity.CENTER); c.addView(s,lp(-1,-2)); return c; }
    LinearLayout card(){ LinearLayout c=new LinearLayout(this); c.setPadding(16,14,16,14); c.setBackgroundResource(R.drawable.card_bg); return c; }
    TextView txt(String s,float size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); return t; }
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);} LinearLayout.LayoutParams weightLp(float w){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,w);p.setMargins(0,0,7,0);return p;}
    GradientDrawable round(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(r);return g;}

    void pickTime(){ new TimePickerDialog(this,(v,h,m)->{chosen.set(Calendar.HOUR_OF_DAY,h);chosen.set(Calendar.MINUTE,m);chosen.set(Calendar.SECOND,0);reminderStatus.setText(String.format(Locale.getDefault(),"Reminder time: %02d:%02d",h,m));},chosen.get(Calendar.HOUR_OF_DAY),chosen.get(Calendar.MINUTE),true).show(); }

    void addReminderDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(28,8,28,4);
        EditText e=new EditText(this);e.setHint("What do you want to remember?");e.setTextColor(white);e.setHintTextColor(muted);box.addView(e,lp(-1,58));
        Button time=new Button(this);time.setText("Choose time");box.addView(time,lp(-1,54));
        time.setOnClickListener(v->pickTime());
        new AlertDialog.Builder(this).setTitle("Add Reminder").setView(box).setPositiveButton("Set reminder",(d,w)->setReminder(e.getText().toString().trim())).setNegativeButton("Cancel",null).show();
    }

    void setReminder(String title){ if(title.isEmpty()){Toast.makeText(this,"Please enter a reminder",Toast.LENGTH_SHORT).show();return;} Intent i=new Intent(this,ReminderReceiver.class);i.putExtra("title",title);int id=(int)(System.currentTimeMillis()%100000);PendingIntent pi=PendingIntent.getBroadcast(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);long when=chosen.getTimeInMillis();if(when<=System.currentTimeMillis())when+=86400000L;am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);String tm=new SimpleDateFormat("dd MMM, hh:mm a",Locale.getDefault()).format(new Date(when));reminderStatus.setText("✓  "+title+"\n     "+tm);Toast.makeText(this,"Reminder saved",Toast.LENGTH_SHORT).show(); }

    void showSettings(){
        String[] items={"Morning football update  •  10:00 AM","Night football update  •  10:00 PM","Men's football only  •  ON","Notifications  •  ON","Developer  •  Atik"};
        new AlertDialog.Builder(this).setTitle("Settings").setItems(items,(d,w)->{}).setPositiveButton("Done",null).show();
    }

    void loadFootball(){ footballText.setText("Loading today's fixtures…"); new Thread(()->{try{String today=new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());URL u=new URL("https://api.cordax.net/Fixtures?from="+today+"&to="+today+"&status=Scheduled");HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("GET");c.setConnectTimeout(9000);c.setReadTimeout(9000);BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder sb=new StringBuilder();String line;while((line=r.readLine())!=null)sb.append(line);String out=formatMatches(new JSONArray(sb.toString()));runOnUiThread(()->footballText.setText(out));}catch(Exception e){runOnUiThread(()->footballText.setText("Online fixture data is unavailable right now.\nTap ↻ to retry."));}}).start(); }
    String formatMatches(JSONArray a){StringBuilder b=new StringBuilder();int shown=0;for(int i=0;i<a.length()&&shown<6;i++){try{JSONObject x=a.getJSONObject(i);String home=x.optString("home",x.optString("HomeTeam",""));String away=x.optString("away",x.optString("AwayTeam",""));String comp=x.optString("competition",x.optString("Competition",""));String time=x.optString("date",x.optString("Date",""));if(home.isEmpty()&&away.isEmpty())continue;b.append("• ").append(home).append("  vs  ").append(away).append("\n");if(!comp.isEmpty())b.append("  ").append(comp).append("  ");if(!time.isEmpty())b.append(time);b.append("\n\n");shown++;}catch(Exception ignored){}}if(shown==0)b.append("No scheduled fixtures found for today.");return b.toString();}
}
