package com.example.reminderapp;
import android.app.*; import android.content.*; import android.os.*;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){String t=i.getStringExtra("title"); String ch="reminders"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Reminders",NotificationManager.IMPORTANCE_HIGH));
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
  b.setSmallIcon(R.drawable.ic_launcher).setContentTitle("My Reminder").setContentText(t==null?"You have a reminder":t).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH);
  nm.notify((int)System.currentTimeMillis(),b.build());
 }
}
