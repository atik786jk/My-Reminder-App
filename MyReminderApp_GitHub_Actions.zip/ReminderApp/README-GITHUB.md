# My Reminder — GitHub Actions APK Build

This repository is configured to build an installable Android debug APK online with GitHub Actions.

## Build from GitHub browser

1. Create a new GitHub repository (for example `MyReminderApp`).
2. Upload all files/folders from this ZIP to the repository root.
3. Make sure `.github/workflows/build-apk.yml` is present.
4. Open the **Actions** tab.
5. Select **Build Android APK**.
6. Press **Run workflow** (or push to `main`; it also builds automatically).
7. Wait for the workflow to finish with a green check.
8. Open that workflow run and scroll to **Artifacts**.
9. Download **MyReminder-debug-apk**.
10. Extract the downloaded artifact and install `app-debug.apk` on Android.

## Notes

- This is a debug APK for personal testing, not a Play Store release build.
- The app currently contains manual reminders and an online football-fixture fetch attempt.
- The football endpoint can change or become unavailable; the app shows an unavailable message instead of pretending the data is current.
