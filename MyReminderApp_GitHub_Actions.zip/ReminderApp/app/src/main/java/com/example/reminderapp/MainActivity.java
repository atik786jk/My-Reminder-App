package com.example.reminderapp;

import android.app.*; import android.os.*; import android.content.*; import android.view.*; import android.widget.*;
import java.net.*; import java.io.*; import java.util.*; import org.json.*;

public class MainActivity extends Activity {
 EditText title; TextView status, matches, footballStatus; Calendar chosen=Calendar.getInstance();

 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  title=findViewById(R.id.title); status=findViewById(R.id.status); matches=findViewById(R.id.matches); footballStatus=findViewById(R.id.footballStatus);
  findViewById(R.id.pick).setOnClickListener(v->pickTime()); findViewById(R.id.add).setOnClickListener(v->setReminder());
  findViewById(R.id.football).setOnClickListener(v->loadFootball());
  if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},10);
  loadFootball();
 }
 void pickTime(){new TimePickerDialog(this,(v,h,m)->{chosen.set(Calendar.HOUR_OF_DAY,h);chosen.set(Calendar.MINUTE,m);chosen.set(Calendar.SECOND,0);status.setText(String.format(Locale.getDefault(),"সময়: %02d:%02d",h,m));},chosen.get(Calendar.HOUR_OF_DAY),chosen.get(Calendar.MINUTE),true).show();}
 void setReminder(){String t=title.getText().toString().trim(); if(t.isEmpty()){title.setError("কাজের নাম দাও");return;}
  Intent i=new Intent(this,ReminderReceiver.class);i.putExtra("title",t);
  PendingIntent pi=PendingIntent.getBroadcast(this,(int)System.currentTimeMillis(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);long when=chosen.getTimeInMillis();if(when<=System.currentTimeMillis())when+=86400000L;
  am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi);status.setText("✅ সেট হয়েছে: "+t+"\n"+new Date(when));title.setText("");
 }
 void loadFootball(){
  footballStatus.setText("Football data: loading...");
  new Thread(()->{
   try{
    String today=new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());
    URL u=new URL("https://api.cordax.net/Fixtures?from="+today+"&to="+today+"&status=Scheduled");
    HttpURLConnection c=(HttpURLConnection)u.openConnection();c.setRequestMethod("GET");c.setConnectTimeout(10000);c.setReadTimeout(10000);
    BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream()));StringBuilder sb=new StringBuilder();String line;while((line=r.readLine())!=null)sb.append(line);
    String out=formatMatches(new JSONArray(sb.toString()));
    runOnUiThread(()->{footballStatus.setText("Football data: online ✓");matches.setText(out);});
   }catch(Exception e){runOnUiThread(()->footballStatus.setText("Football data: unavailable (tap again to retry)"));}
  }).start();
 }
 String formatMatches(JSONArray a){
  StringBuilder b=new StringBuilder("আজকের scheduled Men's fixtures (source data):\n\n");
  int n=Math.min(a.length(),40);for(int i=0;i<n;i++){try{JSONObject x=a.getJSONObject(i);String home=x.optString("home",x.optString("HomeTeam",""));String away=x.optString("away",x.optString("AwayTeam",""));String comp=x.optString("competition",x.optString("Competition",""));String time=x.optString("date",x.optString("Date",""));b.append("• ").append(home).append(" vs ").append(away).append("\n  ").append(comp).append(" — ").append(time).append("\n\n");}catch(Exception ignored){}}
  if(n==0)b.append("আজকের data পাওয়া যায়নি।"); return b.toString();
 }
}