package com.example.reminderapp;
import android.app.*; import android.content.*; import android.os.*;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){String t=i.getStringExtra("title"); String ch="reminders"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"Reminders",NotificationManager.IMPORTANCE_HIGH));
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Reminder").setContentText(t).setAutoCancel(true);
  nm.notify((int)System.currentTimeMillis(),b.build());
 }
}